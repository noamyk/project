﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BE;
using DAL;

namespace BL
{
    public delegate bool conditionDelegate(Test b);
    public interface IBL
    {
        void AgeTr(int num);//בודקת האם התלמיד גדול מגיל 18
        void AgeTe(int num);// בודקת אם הבוחן גדול או קטן מ40

        
	
	 
		  
		 
		void TestGap (Test b);
		void CheckLessons (Trainee d, Test b);
		void Availability (Test b);
		void TesterMax (Tester o);
		void CheckFields (Test b);
		void TestTime (Tester o, Trainee d, Test b);
		void CheckVehicle (Trainee d, Test b);
		bool SetTest (Tester o, Trainee d);
		List<Tester> TesterArea (string address);
		List<Tester> TesterTime (DateTime time);
		List<Test> Condition_Tests(conditionDelegate condition);
		int NumTraineeTests (Trainee d);
		bool PassedTest (Trainee d);
		List<Test> TestDate(DateTime time);
		List<Tester> TesterGrouping();
		List<Trainee> TraineeTeacherGrouping();
		List<Trainee> TraineeSchoolGrouping();
		List<Trainee> TraineeTestGrouping();


		void AddTester(Tester O);
		void deleteTester(int num);
		void UpdateTester(Tester O);


		void AddTrainee(Trainee D);
		void deleteTrainee(int num);
		void updateTrainee(Trainee D);


		void AddTest(Test B);
		void deleteTest(Test num);
		void UpdateTest(Test B);

		List<Tester> TesterList();
		List<Trainee> TraineeList();
		List<Test> TestList();
    }
}

    

