﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading.Tasks;
using BE;
using DAL;
using static BL.IBL;

namespace BL
{
    class BL_imp : IBL
    {
        /// <summary>
        /// לאפשר רק לתלמיד מעל גיל 18 
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        Idal DAL = FactoryDal.getdal();

        public int Range { get; private set; }

        public void AgeTr(int num)
        {
            int ageMinS = 18;
            if (num < ageMinS)
                throw new Exception("אין אפשרות להבחן מתחת לגיל 18");
        }
        /// <summary>
        /// לאפשר רק לבוחן מעל גיל 40 
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        public void AgeTe(int num)
        {
            
            if (num < 40)
                throw new Exception("אין אפשרות לבחון מתחת לגיל 40");
        }
        /// <summary>
		///  לא מאפשר לתלמיד להוסיף מבחן לפני שעבר שבוע מהפעם הקודמת
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void TestGap(Test b)
        {
            Range = b.confirmationtestdate.DayOfYear - b.PreviousTestDate.DayOfYear;
            if
                (b.PreviousTestDate != null && Range < 7)
            {
                throw new Exception("The tests are too close together");
            }
        }
          

				

		/// <summary>
		/// לא מאפשר לתלמיד להוסיף מבחן לפני שעבר 20 שיעורים
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void CheckLessons(Trainee d, Test b)
		{
            if (d.NumberOfLessons < 20)
				throw new Exception("You have not done enough lessons");
		}

		/// <summary>
		///  אין אפשרות להוסיף מבחן אם אין בוחן זמין, במקרה כזה הפונקציה תתן תאריך אחר
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void Availability(Test b)
		{
			bool flag = false;
			DayOfWeek today = DateTime.Now.DayOfWeek;
            foreach (Tester item in DAL.getListTesters()) 
			{
                if (b.confirmationtestdate.DayOfWeek >= DayOfWeek.Sunday && b.confirmationtestdate.DayOfWeek <= DayOfWeek.Thursday)
                  
                        flag = true;
				
			}
			 
		}

		/// <summary>
		/// does not allow tester to be added to test if he has surpassed his weekly test limit
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void TesterMax(Tester o)
		{
			if (o.NumTests > Configuration.maxTests)
				throw new Exception("You have done too many tests");
		}

		/// <summary>
		/// does not allow test to be modified if it is missing fields
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void CheckFields(Test b)
		{
			var properties = b.GetType().GetProperties(System.Reflection.BindingFlags.Public);
			foreach (var prop in properties)
			{
				if (!prop.CanRead)
					continue;
				else if (prop.PropertyType.IsValueType)
					continue;
				Object value = prop.GetValue(prop.GetGetMethod().IsStatic ? null : b);
				if (Object.ReferenceEquals(null, value))
					throw new Exception("not all fields have been filled in");
				String str = value as String;
				if (null != str)
					if (str.Equals(""))
						throw new Exception("not all fields have been filled in");
			}
		}

		/// <summary>
		/// does not allow test to be added if tester or trainee already has test at the same time
		/// </summary>
		/// <param name="o"></param>
		/// <param name="d"></param>
		/// <param name="b"></param>
		/// <returns></returns>
		public void TestTime(Tester o, Trainee d, Test b)
		{
			 
				if (b.confirmationtestdate == o.TestTimes1)
					throw new Exception("tester already has test at that time");
		    
				if (b.confirmationtestdate == d.TestTimes2)
					throw new Exception("trainee already has test at that time");
		}

		/// <summary>
		/// does not allow test to be added if trainee has already passed test on that vehicle type
		/// </summary>
		/// <param name="d"></param>
		/// <param name="b"></param>
		/// <returns></returns>
		public void CheckVehicle(Trainee d, Test b)
		{
			if (d.PassedTests == b.TestType)
				throw new Exception("trainee has already passed test on that vehicle type");
		}

		/// <summary>
		/// ensures that the vehicle type that the trainee learned to drive is the same as the testers vehicle
		/// </summary>
		/// <param name="o"></param>
		/// <param name="d"></param>
		/// <returns></returns>
		public bool SetTest(Tester o, Trainee d)
		{
			if (o.CarType == d.CarType)
				return true;
			else return false;
		}

		/// <summary>
		/// returns list of all testers within certain distance of the given address
		/// </summary>
		/// <param name="address"></param>
		/// <returns></returns>
		public List<Tester> TesterArea(string address)
		{
			var list = from item in DAL.getListTesters()
					   where item.Address == address
					   select item;
			List<Tester> newList = new List<Tester>();
			foreach (var s in list)
				newList.Add(s);
			return newList;

		}

		// <summary>
		/// returns list of all testers who are free at the given time 
		/// </summary>
		/// <param name="time"></param>
		/// <returns></returns>
		public List<Tester> TesterTime(DateTime time)
		{
			List<Tester> newList = new List<Tester>();
			foreach (Tester item in DAL.getListTesters())
				if (item.TestTimes1.Find(s => s.Date == time) != null)
					newList.Add(item);
			return newList;
		}

		// <summary>
		/// returns list of tests organized according to certain condition
		/// </summary>
		/// <param name="condition"></param>
		/// <returns></returns>
        public List<Test> Condition_Tests(conditionDelegate Condition)
		{
            var list = from item in DAL.getListTests  ()
					   where Condition(item)
					   select item;
			List<Test> newList = new List<Test>();
			foreach (var s in list)
				newList.Add(s);
			return newList;

		}

		// <summary>
		/// returns number of tests a trainee has done
		/// </summary>
		/// <param name="d></param>
		/// <returns></returns>
		public int NumTraineeTests(Trainee d)
		{
			return d.NumTests;
		}

		// <summary>
		/// checks if trianee has passed any tests
		/// </summary>
		/// <param name="d></param>
		/// <returns></returns>
		public bool PassedTest(Trainee d)
		{
			if (d.PassedTests == false)
				return false;
			return true;
		}

		// <summary>
		/// מחזיר את כל המבחנים
		/// </summary>
		/// <param name="time></param>
		/// <returns></returns>
		public List<Test> TestDate(DateTime time)
		{
            var list = from item in DAL.getListTests ()
					   where item.FinalTestDate.Date == time.Date
					   select item;
			List<Test> newList = new List<Test>();
			foreach (var s in  list)
				newList.Add(s);
			return newList;
		}

		public List<Tester> TesterGrouping()
		{
			List<Tester> TesterGroup = new List<Tester>();
			IEnumerable<IGrouping<CarType, Tester>> TesterGroup1 = from item in DAL.getListTesters()
															         group item by item.VehicleType;
			foreach (var group in TesterGroup1)
			{
				foreach (var item in group)
				{
					TesterGroup.Add(item);
				}
			}
			return TesterGroup;													
		}

		public List<Trainee> TraineeTeacherGrouping()
		{
			List<Trainee> TraineeTeacherGroup = new List<Trainee>();
			IEnumerable<IGrouping<string, Trainee>> TraineeTeacherGroup1 = from item in DAL.getListTrainees()
																	       group item by item. Name;
			foreach (var group in TraineeTeacherGroup1)
			{
				foreach (var item in group)
				{
					TraineeTeacherGroup.Add(item);
				}
			}
			return TraineeTeacherGroup;
		}

		public List<Trainee> TraineeSchoolGrouping()
		{
			List<Trainee> TraineeSchoolGroup = new List<Trainee>();
			IEnumerable<IGrouping<string, Trainee>> TraineeSchoolGroup1 = from item in DAL.getListTrainees()
																		   group item by item.SchoolName;
			foreach (var group in TraineeSchoolGroup1)
			{
				foreach (var item in group)
				{
					TraineeSchoolGroup.Add(item);
				}
			}
			return TraineeSchoolGroup;
		}

		public List<Trainee> TraineeTestGrouping()
		{
			List<Trainee> TraineeTestGroup = new List<Trainee>();
			IEnumerable<IGrouping<int, Trainee>> TraineeTestGroup1 = from item in DAL.getListTrainees()
																     group item by item.NumTests;
			foreach (var group in TraineeTestGroup1)
			{
				foreach (var item in group)
				{
					TraineeTestGroup.Add(item);
				}
			}
			return TraineeTestGroup;
		}

		public void AddTester(Tester O)
		{
            int num = O.DateOfBirth.Year - DateTime.Today.Year;
            AgeTe(num);
			DAL.addTester(O);
		}

		public void deleteTester(int num)
		{ 
			DAL.deleteTester(num);
		}

		public void UpdateTester(Tester O)
		{
            AgeTe(DAL.getListTesters().Find(s => s.ID == O.ID).Birthday.Year);
            DAL.updateTester(O);
		}

		public void AddTrainee(Trainee D)
		{
            int num = D.DateOfBirth.Year -   DateTime.Today.Year;
			DAL.updateTrainee(D);
		}

		public void deleteTrainee(int num)
		{
            DAL.deleteTrainee(num);
		}

		public void updateTrainee(Trainee D)
		{
            AgeTr(DAL.getListTrainees().Find(s => s.ID == D.ID).Birthday.Year);
            DAL.updateTrainee(D);
		}

		public void AddTest(Test B)
		{
            Trainee tr = DAL.getListTrainees().Find(s => s.ID == B.NumTrainee);
            Tester te = DAL.getListTesters().Find(s => s.ID  == B.NumTester);
			if (SetTest(te, tr))
			{
				TestGap(B);
				CheckLessons(tr, B);
				Availability(B);
				TesterMax(te);
				TestTime(te, tr, B);
				CheckVehicle(tr, B);
                DAL.addTest(B);
			}		    
		}

		public void deleteTest(Test o)
		{
            DAL.deleteTest(o);
		}

		public void UpdateTest(Test B)
		{
			CheckFields(B);
            DAL.updateTest(B);
		}

		public List<Tester> TesterList()
		{
            return DAL.getListTesters();
		}

		public List<Trainee> TraineeList()
		{
            return DAL.getListTrainees();
		}

		public List<Test> TestList()
		{
            return DAL.getListTests();
		}
	}
}
   
