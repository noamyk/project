﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using BE;
using DS;
using System.ComponentModel;
using System.IO;
using System.Reflection;













namespace DAL
    {
        class Dal_XML_imp1: Idal
        {
            //  XElement OrderRoot;
            //string OrderPath = @"OrderXml.xml";
            //XElement DishRoot;
            //string DishPath = @"DishXml.xml";
            //XElement BranchRoot;
            //string BranchPath = @"BranchXml.xml";
            //XElement Ordered_DishRoot;
            //string Ordered_DishPath = @"Ordered_DishXml.xml";
            //XElement OrderNumRoot;
            //string OrderNumPath = @"OrderNumXml.xml";
            //XElement BranchNumRoot;
            //string BranchNumPath = @"BranchNumXml.xml";
            //XElement DishNumRoot;
            //string DishNumPath = @"DishNumXml.xml";
            // bool flag = true;

            public void addTester(Tester t) //הוספת בוחן
        {

                if (t.ID < 400000000)
                    throw new Exception("נא למלא מספר ת.ז");

                if (t.Name == null)
                    throw new Exception("נא למלא את שם הבוחן");

                if (t.FamilyName == null)
                    throw new Exception("נא למלא את שם המשפחה של הבוחן");

                if (t.Phone < 1111111111 || t.Phone > 1111111111)
                    throw new Exception("מספר פלאפון אינו תקין");
            }



            public void addTest(Test t) //הוספת מבחן
            {

                if (t.TestNumber < 0)
                    throw new Exception(" נא למלא את מספר המבחן ");

                if (t.TesterAddress == null)
                    throw new Exception("נא להזין את כתובת הבוחן");

                if (t.TraineeAddress == null)
                    throw new Exception("נא להזין את כתובת הנבחן");

                if (t.TestCity == null)
                    throw new Exception("נא למלא את העיר בה מתבצע המבחן ");

            if (t.IdOfTrainee < 400000000)
                throw new Exception("נא למלא את ת.ז של הנבחן");

            if (t.PhoneTrainee < 1111111111 || t.PhoneTrainee > 1111111111)
            {
                throw new Exception("נא למלא את מספר הטלפון");
            }

            if (t.Date == null)
                throw new Exception("נא למלא את תאריך המבחן");

        }

        public void addTrainee(Trainee t) //הוספת נבחן
        {

            if (t.ID < 400000000)
                throw new Exception("נא למלא מספר ת.ז");

            if (t.Name == null)
                throw new Exception("נא למלא את שם הנבחן");

            if (t.FamilyName == null)
                throw new Exception("נא למלא את שם המשפחה של הנבחן");

            if (t.Phone < 1111111111 || t.Phone > 1111111111)
                throw new Exception("מספר פלאפון אינו תקין");
        }

        public void deleteTester(string Name)
        {
            
        }

        public void deleteTest(string Name)
        {

        }

        public void deleteTrainee(string Name)
        {

        }

        public void updateTester(Tester t) //עדכון בוחן
        {

            if (t.ID < 400000000)
                throw new Exception("נא למלא מספר ת.ז");

            if (t.Name == null)
                throw new Exception("נא למלא את שם הבוחן");

            if (t.FamilyName == null)
                throw new Exception("נא למלא את שם המשפחה של הבוחן");

            if (t.Phone < 1111111111 || t.Phone > 1111111111)
                throw new Exception("מספר פלאפון אינו תקין");
        }

      public  void updateTest(Test t) //עדכון מבחן
        {
            if (t.TestNumber < 0)
                throw new Exception(" נא למלא את מספר המבחן ");

            if (t.TesterAddress == null)
                throw new Exception("נא להזין את כתובת הבוחן");

            if (t.TraineeAddress == null)
                throw new Exception("נא להזין את כתובת הנבחן");

            if (t.TestCity == null)
                throw new Exception("נא למלא את העיר בה מתבצע המבחן ");

            if (t.IdOfTrainee < 400000000)
                throw new Exception("נא למלא את ת.ז של הנבחן");

            if (t.PhoneTrainee < 1111111111 || t.PhoneTrainee > 1111111111)
            {
                throw new Exception("נא למלא את מספר הטלפון");
            }

            if (t.Date == null)
                throw new Exception("נא למלא את תאריך המבחן");
        }

        public void updateTrainee(Trainee t) //עדכון נבחן
        {
            if (t.ID < 400000000)
                throw new Exception("נא למלא מספר ת.ז");

            if (t.Name == null)
                throw new Exception("נא למלא את שם הנבחן");

            if (t.FamilyName == null)
                throw new Exception("נא למלא את שם המשפחה של הנבחן");

            if (t.Phone < 1111111111 || t.Phone > 1111111111)
                throw new Exception("מספר פלאפון אינו תקין");
        }

    }
    }



