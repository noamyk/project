﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using BE;
using DS;

namespace DAL
{
    public class Dal_imp : Idal
    {
        public void addTester(Tester t)
        {
            DataSource.Testers.Add(t);
        }
        public bool findTester(string ID)
        {
            foreach (Tester T in DataSource.Testers)
            {
                if (T.ID == ID)
                    return true;
            }
            return false;
        }
        public Tester getListTesters(string ID)
        {
            foreach (Tester T in DataSource.Testers)
            {
                if (T.ID == ID)
                    return T;
            }
            throw new Exception("Tester Couldn't find");
        }
        public void updateTester(Tester t)
        {
            bool flag = true;
            for (int i = 0; i < DataSource.Testers.Count; i++)
            {
                if (DataSource.Testers[i].ID == t.ID)
                {
                    flag = false;
                    DataSource.Testers[i] = t;
                }
                if (flag)
                {
                    throw new Exception("Tester Couldn't find");
                }
            }
        }


        public void deleteTester(int testerId)
        {
            for (int i = 0; i < DataSource.Testers.Count; i++)
            {
                if (testerId == DataSource.Testers[i].testerId)
                {
                    DataSource.Testers.RemoveAt(i);

                }
            }
        }




        public void addTest(Test t)
        {
            DataSource.Tests.Add(t);
        }
        public bool findTest(string ID)
        {
            foreach (Test T in DataSource.Tests)
            {
                if (T.IdTester == ID)
                    return true;
            }
            return false;
        }
        public Test getTest(string ID)
        {
            foreach (Test T in DataSource.Tests)
            {
                if (T.IdTester == ID)
                    return T;
            }
            throw new Exception("Test  Couldn't find");
        }
        public void updateTest(Test t)
        {
            bool flag = true;
            for (int i = 0; i < DataSource.Tests.Count; i++)
            {
                if (DataSource.Tests[i].IdTester == t.IdTester)
                {
                    flag = false;
                    DataSource.Tests[i] = t;
                }
                if (flag)
                    throw new Exception("Test  Couldn't find");

            }
        }
        public void deleteTest(Test o)
        {
            for (int i = 0; i < DataSource.Tests.Count; i++)
            {
                if (o == DataSource.Tests[i].o)
                {
                    DataSource.Tests.RemoveAt(i);

                }
            }
        }

        public void addTrainee(Trainee s)
        {
            DataSource.Trainees.Add(s);
        }
        public bool findTrainee(string ID)
        {
            foreach (Trainee T in DataSource.Trainees)
            {
                if (T.ID == ID)
                    return true;
            }
            return false;
        }
        public Trainee getTrainee(string ID)
        {
            foreach (Trainee T in DataSource.Trainees)
            {
                if (T.ID == ID)
                    return T;
            }
            throw new Exception("Trainee Couldn't find");
        }
        public void updateTrainee(Trainee s)
        {
            bool flag = true;
            for (int i = 0; i < DataSource.Trainees.Count; i++)
            {
                if (DataSource.Trainees[i].ID == s.ID)
                {
                    flag = false;
                    DataSource.Trainees[i] = s;
                }
                if (flag)
                {
                    throw new Exception("Trainee Couldn't find");
                }
            }
        }




        public void deleteTrainee(int numberS)
        {
            for (int i = 0; i < DataSource.Trainees.Count; i++)
            {
                if (numberS == DataSource.Trainees[i].numberS)
                {
                    DataSource.Trainees.RemoveAt(i);

                }
            }
        }


        public List<Tester> getListTesters()
        {
            return DataSource.Testers;
        }
        public List<Test> getListTests()
        {
            return DataSource.Tests;


        }
        public List<Trainee> getListTrainees()
        {
            return DataSource.Trainees;
        }
    }
}
     
   









        
