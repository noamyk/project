﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BE
{
    public class Test
    {
        public Test o;
        
      
        public long IdTester { get; set; } // id of Tester
      public long IdOfTrainee { get; set; }  // id of Student
        public int TestNumber { get; set; }  // number of the Test
        public string DateAndTime { get; set; }  //  date and time of the Test
        public bool Grade { get; set; }  //  Grade of the Test
        public string TesterAddress { get; set; }   //the Address of the  tester
        public string TraineeAddress { get; set; }   //the Address of the  trainee
        public string Notes { get; set; }
        public string TestCity { get; set; }
        public DateTime PreviousTestDate { get; set; }
        public bool TestType { get; set; }
        public DateTime Date { get; set; }
        // Date int year int mounth int day int hour, int minute, int second int milisecond
        public string NumTrainee { get; set; }
        public long PhoneTrainee { get; set; }
        public string NumTester { get; set; }
        public DateTime confirmationTestDate { get; set; }
        public string WorkingHours { get; set; }
        public DateTime DayOfWeek { get; set; }
        public string DayOfYear { get; set; }
        public int Range { get; set; }
        public DateTime FinalTestDate { get; set; }



    }
}
