﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Tester
    {
        public long ID { get; set; } 
        public string FamilyName { get; set; }  
        public string Name { get; set; }  
        public DateTime DateOfBirth { get; set; }  
        public string Gender { get; set; }  
        public long  Phone { get; set; }  
        public string Address { get; set; }  
        public int YearsOfExperiment { get; set; }
        public int TheMaximumNumberOfWeeklyTests { get; set; }
        public int NumTests { get; set; }
        public  string  WorkingHours { get; set; }
        public DateTime TestTimes1 { get; set; }
    public DateTime Birthday { get; set; }
        public string CarType { get; set; }
        
        public IGrouping VehicleType { get; set; }

        bool[,] Matrix = new bool[6, 5];
        public int testerId;

    
    }
}
