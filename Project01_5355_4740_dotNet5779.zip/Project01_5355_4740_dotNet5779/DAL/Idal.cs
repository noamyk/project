﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using DS;



namespace DAL
{

    public interface Idal
    {
        bool findTester(string  tt);
        void addTester(Tester t); //הוספת בוחן
        void deleteTester(string testerId); //  מחיקת בוחן
        void updateTester(Tester t); //עדכון פרטי בוחן קיימת
            
         


        bool findTrainee(Trainee tt);
        void addTrainee(Trainee s);   //הוספת תלמיד
        void deleteTrainee(Trainee ID);   //מחיקת תלמיד
        void updateTrainee(Trainee ss);  //עדכון תלמיד קיים
        
        


        bool findTest(string tt);
        void addTest(Test o);  //הוספת מבחן
        void deleteTest(  Test o);   //מחיקת מבחן
        void updateTest(Test o);  //עדכון מבחן בסיומו 




        List<Test> getListTests();  // קבלת רשימת כל המבחנים
        List<Trainee> getListTrainees();  //  קבלת רשימת כל התלמידים

        List<Tester> getListTesters();  //קבלת רשימת כל הבוחנים
        void deleteTest(string o);
        void deleteTrainee(string name);
    }
}   
