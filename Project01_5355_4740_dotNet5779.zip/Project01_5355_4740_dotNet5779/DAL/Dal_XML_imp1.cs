﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using BE;
using DS;
using System.ComponentModel;
using System.IO;
using System.Reflection;
namespace DAL
{
    public class Dal_XML_imp : Idal
    {
        XElement TesterRoot;
        string TesterPath = @"TesterXml.xml";

        XElement TestRoot;
        string TestPath = @"TestXml.xml";

        XElement TraineeRoot;
        const string TraineePath = @"Trainee.XML"; //orderPath


        public Dal_XML_imp()//בנאי
        {
            try
            {
                if (!File.Exists(TesterPath))//dish
                {
                    TesterRoot = new XElement("testers");
                    TesterRoot.Save(TesterPath);
                }
                else TesterRoot = XElement.Load(TesterPath);
                if (!File.Exists(TestPath))//branch
                {
                    TestRoot = new XElement("tests");
                    TestRoot.Save(TestPath);
                }
                else TestRoot = XElement.Load(TestPath);

                if (!File.Exists(TraineePath))//order
                {
                    TraineeRoot = new XElement("trainee");
                    TraineeRoot.Save(TraineePath);
                }
                else TraineeRoot = XElement.Load(TraineePath);


            }
            catch
            {
                throw new Exception("File upload problem");
            }

        }

        #region  Trainee
        public bool findTrainee(Trainee dd)
        {
            XElement  TraineeElement ;
            TraineeElement = (from p in TraineeRoot.Elements()
                              where (p.Element("TraineeName").Value) ==  dd.Name 
                              select p).FirstOrDefault();
            if (TraineeElement == null)
                return false;
            return true;
        }
        public void addTrainee(Trainee o)
        {
            XElement TraineeName = new XElement(" TraineeName", o.Name);
            XElement TraineeID = new XElement("TraineeID", o.ID);
            XElement TraineeFamilyName = new XElement("TraineeFamilyName", o.FamilyName);
            XElement DateOfBirth = new XElement("DateOfBirth", o.DateOfBirth);
            XElement Gender = new XElement("Gender", o.Gender);
            XElement Phone = new XElement("Phone", o.Phone);
            XElement Address = new XElement("Address", o.Address);
            XElement GearBox = new XElement("GearBox", o.GearBox);
            XElement SchoolName = new XElement("SchoolName", o.SchoolName);
            XElement NumberOfLessons = new XElement("NumberOfLessons", o.NumberOfLessons);

            TraineeRoot.Add(new XElement("Trainee", TraineeName, TraineeID, TraineeFamilyName, DateOfBirth, Gender, Phone, Address, GearBox, SchoolName, NumberOfLessons));
            TraineeRoot.Save(TraineePath);

        }
        public void deleteTrainee(Trainee  o)
        {
            try
            {

                XElement TraineeElement;
                TraineeElement = (from p in TraineeRoot.Elements()
                                  where p.Element("TraineeNumber").Value == o.Name.ToString()  
                                  select p).FirstOrDefault();
            }


            catch
            {
                throw new Exception("The Trainee dosn't exsist in the system");
            }
        }
        public void updateTrainee(Trainee o)
        {
            TraineeRoot = XElement.Load(TraineePath);
            XElement Trainee = (from item in TraineeRoot.Elements()
                                where item.Element("TraineeName").Value == o.Name.ToString()
                                select item).FirstOrDefault();
            Trainee.Element("TraineeID").Value = o.ID.ToString();
            Trainee.Element("TraineeFamilyName").Value = o.FamilyName.ToString();
            Trainee.Element("DateOfBirth").Value = o.DateOfBirth.ToString();
            Trainee.Element("Gender").Value = o.Gender.ToString();
            Trainee.Element("Phone").Value = o.Phone.ToString();
            Trainee.Element("Address").Value = o.Address.ToString();
            Trainee.Element("GearBox").Value = o.GearBox.ToString();
            Trainee.Element("SchoolName").Value = o.SchoolName.ToString();
            Trainee.Element("NumberOfLessons").Value = o.NumberOfLessons.ToString();
            TraineeRoot.Save(TraineePath);
        }

        public List<Trainee> getListtainees()
        {
            TraineeRoot = XElement.Load(TraineePath);
            List<Trainee> trainees = new List<Trainee>();
            try
            {
                trainees = (from item in TraineeRoot.Elements()
                            select new Trainee()
                            {
                                Name = (item.Element("TraineeName").Value),
                                ID = (item.Element("TraineeID").Value),
                                FamilyName = (item.Element("TraineeFamilyName").Value),
                                Gender = (Gender)Enum.Parse(typeof(Gender), item.Element("Gender").Value),
                                DateOfBirth = Convert.ToDateTime(item.Element("DateOfBirth").Value),
                                Phone = Convert.ToInt64(item.Element("TraineePhone").Value),
                                Address = item.Element(" Address").Value,
                                GearBox = Convert.ToInt32(item.Element("GearBox").Value),
                                SchoolName = (item.Element("SchoolName").Value),
                                NumberOfLessons = Convert.ToInt32(item.Element("NumberOfLessons").Value),
                            }).ToList();
            }
            catch
            {
                trainees = null;
            }

            return trainees;
        }

        public IEnumerable<Trainee> getAllOrder(Func<Trainee, bool> predicat = null)
        {
            IEnumerable<Trainee> trainee;
            try
            {

                trainee = (from item in TraineeRoot.Elements()
                           select new Trainee()
                           {
                               Name = (item.Element("TraineeName").Value),
                               ID = (item.Element("TraineeID").Value),
                               FamilyName = (item.Element("TraineeFamilyName").Value),
                               Gender = (Gender)Enum.Parse(typeof(Gender), item.Element("Gender").Value),
                               DateOfBirth = Convert.ToDateTime(item.Element("DateOfBirth").Value),
                               Phone = Convert.ToInt64(item.Element("TraineePhone").Value),
                               Address = item.Element(" Address").Value,
                               GearBox = Convert.ToInt32(item.Element("GearBox").Value),
                               SchoolName = (item.Element("SchoolName").Value),
                               NumberOfLessons = Convert.ToInt32(item.Element("NumberOfLessons").Value),
                           }).ToList();
                if (predicat != null)
                {
                    trainee = trainee.Where(predicat);

                }
            }
            catch
            {
                trainee = null;
            }
            return trainee;
        }
        #endregion

        #region Tester

        public bool findTester(string id)//מחזיר "אמת" כאשר כאשר המנה נמצאה בקובץ
        {
            XElement TesterElement;
            TesterElement = (from p in TesterRoot.Elements()
                             where (p.Element("TesterId").Value) == id
                             select p).FirstOrDefault();
            if (TesterElement == null)
                return false;
            return true;
        }

        public void addTester(Tester tester)//הוספת מנה
        {
            if (findTester(tester.ID))
                throw new Exception("The tester is already exsist in the system");
            XElement testerId = new XElement("testerId", tester.ID);
            XElement testerName = new XElement("testerName", tester.Name);
            XElement testerFamilyName = new XElement("testerFamilyName", tester.FamilyName);
            XElement DateOfBirth = new XElement("DateOfBirth", tester.DateOfBirth);
            XElement Gender = new XElement("Gender", tester.Gender);
            XElement Phone = new XElement("Phone ", tester.Phone);
            XElement Address = new XElement("Address ", tester.Address);
            XElement YearsOfExperiment = new XElement("YearsOfExperiment ", tester.YearsOfExperiment);
            XElement WorkingHours = new XElement("WorkingHours", tester.WorkingHours);
            XElement CarType = new XElement("CarType", tester.CarType);
            TesterRoot.Add(new XElement("tester", testerId, testerName, testerFamilyName, DateOfBirth, Gender, Phone, Address, YearsOfExperiment, WorkingHours, CarType));

            TesterRoot.Save(TesterPath);
        }
        public void deleteTester(string ID)
        {
            XElement TesterElement;
            TesterElement = (from p in TesterRoot.Elements()
                             where (p.Element("TesterId").Value) == ID
                             select p).FirstOrDefault();
            if (TesterElement == null)
                throw new Exception("The Tester dos'nt exsist in the system");
            TesterElement.Remove();
            TesterRoot.Save(TesterPath);

        }
        public IEnumerable<Tester> getAllTester(Func<Tester, bool> predicat = null)
        {
            IEnumerable<Tester> testers;
            try
            {

                testers = from p in TesterRoot.Elements()
                          select new Tester()
                          {
                              ID = (p.Element("testerId").Value),
                              Name = (p.Element("testerName").Value),
                              FamilyName = (p.Element("FamilyName").Value),
                              DateOfBirth = Convert.ToDateTime(p.Element("DateOfBirth").Value),
                              Gender = (Gender)Enum.Parse(typeof(Gender), p.Element("Gender").Value),
                              Phone = Convert.ToInt64(p.Element("Phone").Value),
                              Address = (p.Element("Address").Value),
                              YearsOfExperiment = Convert.ToInt32(p.Element(" YearsOfExperiment").Value),
                              WorkingHours = (p.Element(" WorkingHours").Value),
                              CarType = (CarType)Enum.Parse(typeof(CarType), p.Element("CarType").Value),
                          };
                if (predicat != null)
                {
                    testers = testers.Where(predicat);

                }
            }
            catch
            {
                testers = null;
            }
            return testers;
        }


        public void updateTester(Tester d)
        {
            XElement TesterElement = (from p in TesterRoot.Elements()
                                      where (p.Element("TesterId").Value) == d.ID
                                      select p).FirstOrDefault();
            TesterElement.Element("TesterName").Value = d.Name;
            TesterElement.Element("FamilyName").Value = (d.FamilyName).ToString();
            TesterElement.Element("DateOfBirth").Value = (d.DateOfBirth).ToString();
            TesterElement.Element("Gender").Value = (d.Gender).ToString();
            TesterElement.Element("Phone").Value = (d.Phone).ToString();
            TesterElement.Element("Address").Value = (d.Address).ToString();
            TesterElement.Element("YearsOfExperiment").Value = (d.YearsOfExperiment).ToString();
            TesterElement.Element("WorkingHours").Value = (d.WorkingHours).ToString();
            TesterElement.Element("CarType").Value = (d.CarType).ToString();
            TesterRoot.Save(TesterPath);
        }

        #endregion

        #region Test
        public bool findTest(string TestNumber)
        {
            XElement TestElement;
            TestElement = (from p in TestRoot.Elements()
                           where (p.Element("TestNumber").Value) == TestNumber
                           select p).FirstOrDefault();
            if (TestElement == null)
                return false;
            return true;
        }

        public void addTest(Test b)
        {
            if (findTest(b.TestNumber))
                throw new Exception("The Test is already exsist in the system");
            XElement TestNumber = new XElement("TestNumber", b.TestNumber);
            XElement IdTester = new XElement("IdTester", b.IdTester);
            XElement IdTrainee = new XElement("IdTrainee", b.ID);
            XElement Grade = new XElement("Grade", b.Grade);
            XElement TestCity = new XElement("TestCity", b.TestCity);
            XElement PreviousTestDate = new XElement("PreviousTestDate", b.PreviousTestDate);
            XElement Date = new XElement("Date", b.Date);
            XElement confirmationTestDate = new XElement("confirmationTestDate", b.confirmationTestDate);
            XElement Range = new XElement("Range", b.Range);
            TestRoot.Add(new XElement("Test", TestNumber, IdTester, IdTrainee, Date, Grade, TestCity, PreviousTestDate, confirmationTestDate, Range));
            TestRoot.Save(TestPath);
        }

        public void deleteTest(Test TestNumber)
        {
            XElement TestElement;
            TestElement = (from p in TestRoot.Elements()
                           where (p.Element("TestNumber").Value) == TestNumber.ToString()
                           select p).FirstOrDefault();
            if (TestElement == null)
                throw new Exception("The Test doesn't exsist in the system");
            TestElement.Remove();
            TestRoot.Save(TestPath);
        }

        public void updateTest(Test b)
        {

            XElement TestElement = (from p in TestRoot.Elements()
                                    where (p.Element("TestNumber").Value) == b.TestNumber
                                    select p).FirstOrDefault();
            TestElement.Element("IdTrainee").Value = b.ID;
            TestElement.Element("IdTester").Value = b.IdTester;
            TestElement.Element("Grade").Value = b.Grade.ToString();
            TestElement.Element("TestCity").Value = (b.TestCity);
            TestElement.Element("PreviousTestDate").Value = (b.PreviousTestDate).ToString();
            TestElement.Element("Date ").Value = (b.Date).ToString();
            TestElement.Element("confirmationTestDate ").Value = (b.confirmationTestDate).ToString();
            TestElement.Element("Range ").Value = (b.Range).ToString();
            TestRoot.Save(TestPath);
        }


        public IEnumerable<Test> getAllTest(Func<Test, bool> predicat = null)
        {
            IEnumerable<Test> tests;
            try
            {
                tests = from p in TestRoot.Elements()
                            // where predicat
                        select new Test()
                        {
                            TestNumber = (p.Element("TestNumber").Value),
                            IdTester = p.Element("IdTester").Value,
                            ID = p.Element("IdTrainee").Value,
                            Date = Convert.ToDateTime(p.Element("Date").Value),
                            Grade = Convert.ToBoolean(p.Element("Grade").Value),
                            TestCity = (p.Element("TestCity").Value),
                            PreviousTestDate = Convert.ToDateTime(p.Element("PreviousTestDate").Value),
                            confirmationTestDate = Convert.ToDateTime(p.Element("confirmationTestDat").Value),
                            Range = Convert.ToInt32(p.Element("Range").Value),
                        };
                if (predicat != null)
                {
                    tests = tests.Where(predicat);

                }
            }
            catch
            {
                tests = null;
            }
            return tests;
        }
        #endregion


        public List<Test> getListTests()
        {
            throw new NotImplementedException();
        }



        public List<Tester> getListTesters()
        {
            throw new NotImplementedException();
        }

        public List<Trainee> getListTrainees()
        {
            throw new NotImplementedException();
        }

        public void deleteTest(string o)
        {
            throw new NotImplementedException();
        }

        public void deleteTrainee(string name)
        {
            throw new NotImplementedException();
        }
    }
}


    
 














 