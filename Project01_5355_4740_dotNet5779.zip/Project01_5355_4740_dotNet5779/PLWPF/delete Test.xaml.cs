﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace PLWPF
{
    /// <summary>
    /// Interaction logic for delete_Test.xaml
    /// </summary>
    public partial class delete_Test : Window
    {

        BE.Test test;
        BL.IBL bl;
        public delete_Test ()
        {
            InitializeComponent();
            bl = BL.FactoryBL.getBL();
            test = new BE.Test();
            TestComboBox.ItemsSource = from item in bl.TestList()
                                             select item.ID;
            this.DataContext = test;
        }
        private void DeleteTestButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BE.Test t = new BE.Test();
                test = bl.TestList().FirstOrDefault(b => b.ID== test.ID);
                if (t == null)
                    throw new Exception("the test dosn't exist");
                else bl.deleteTest(t.TestNumber);
                MessageBox.Show("the test \"" + test.TestNumber + "\" Deleted from the system", "Deleted successfully!");
                this.DataContext = test;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
