﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for Testerwindow.xaml
    /// </summary>
    public partial class Testerwindow : Window
    {
        public Testerwindow()
        {
            InitializeComponent();
        }
        private void AddTester_Click(object sender, RoutedEventArgs e)
        {
            new AddTester().ShowDialog();
        }

        private void DeleteTester_Click(object sender, RoutedEventArgs e)
        {
            new deleteTester().ShowDialog();
        }

        private void UpdateTester_Click(object sender, RoutedEventArgs e)
        {
            new update_Tester().ShowDialog();
        }



    }
}
