﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for updateTrainee.xaml
    /// </summary>
    public partial class updateTrainee : Window
    {
        BE.Trainee trainee;
        BL.IBL bl;
        public updateTrainee()
        {
            {
                InitializeComponent();
                trainee = new BE.Trainee();
                this.DataContext = trainee;
                bl = BL.FactoryBL.getBL();
            }
        }
                 
                
             
        private void UpdateTraineeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.updateTrainee(trainee);
               trainee = new BE.Trainee();
                MessageBox.Show("the trainee " + trainee. Name + " update ", "");
                this.DataContext = trainee;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void AddTrainee_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.AddTrainee(trainee);
                MessageBox.Show("the trainee \"" + trainee.Name + "\" is added to the list", "");
                trainee = new BE.Trainee();
                this.gridAddTrainee.DataContext = trainee;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    }
}
