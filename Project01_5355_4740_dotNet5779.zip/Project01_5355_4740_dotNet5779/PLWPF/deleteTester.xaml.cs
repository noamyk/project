﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for deleteTester.xaml
    /// </summary>
    public partial class deleteTester : Window
    {
        BE.Tester tester;
        BL.IBL bl;


        public deleteTester()
        {
            InitializeComponent();
            bl = BL.FactoryBL.getBL();
            tester = new BE.Tester();
            TesterNameComboBox.ItemsSource = from item in bl.TesterList()
                                          select item.ID;
            this.DataContext = tester;
        }
        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BE.Tester t = new BE.Tester();
                tester = bl.TesterList().FirstOrDefault(b => b.ID == tester.ID);
                if (t == null)
                    throw new Exception("the branch dosn't exist");
                else bl.deleteTester(t.Name);
                MessageBox.Show("the tester \"" + tester.Name + "\" Deleted from the system", "Deleted successfully!");
                this.DataContext = tester;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
