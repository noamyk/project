﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BL;
using BE;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for addTest.xaml
    /// </summary>
    public partial class addTest : Window
    {

        Test test;
        IBL bl;
        public addTest()
        {
            InitializeComponent();
            test = new BE.Test();
            this.gridAddTest.DataContext = test;
            bl = FactoryBL.getBL();

        }

        private void addTestButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.AddTest(test);
                MessageBox.Show("the test \"" + test.TestNumber + "\" added to the list", "");
                test = new BE.Test();
                this.gridAddTest.DataContext = test;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void TraineeAddressTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
 
