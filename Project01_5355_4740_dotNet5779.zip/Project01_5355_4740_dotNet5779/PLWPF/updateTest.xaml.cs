﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for updateTest.xaml
    /// </summary>
    public partial class updateTest : Window
    {
        BE.Test test;
        BL.IBL bl;


        public updateTest()
        {
            {
                InitializeComponent();
                test = new BE.Test();
                this.DataContext = test;
                bl = BL.FactoryBL.getBL();
            }
        }
        private void UpdateTestButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.UpdateTest(test);
                test = new BE.Test();
                MessageBox.Show("the test " + test.TestNumber + " update ", "");
                this.DataContext = test;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void AddTest_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.AddTest(test);
                MessageBox.Show("the test \"" + test.TestNumber + "\" added to the list", "");
                test = new BE.Test();
                this.gridAddTest.DataContext = test;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }
    }
}
 








 