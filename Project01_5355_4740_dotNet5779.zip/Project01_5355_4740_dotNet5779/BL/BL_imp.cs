﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading.Tasks;
using BE;
using DAL;
 

namespace BL
{
    class BL_imp : IBL
    {
        /// <summary>
        /// לאפשר רק לתלמיד מעל גיל 18 
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        Idal DAL = FactoryDal.getdal();

        public int Range { get; private set; }

        public void AgeTr(int num)
        {
            int ageMinS = 18;
            if (num < ageMinS)
                throw new Exception("אין אפשרות להבחן מתחת לגיל 18");
        }
        /// <summary>
        /// לאפשר רק לבוחן מעל גיל 40 
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        public void AgeTe(int num)
        {
            
            if (num < 40)
                throw new Exception("אין אפשרות לבחון מתחת לגיל 40");
        }
        /// <summary>
		///  לא מאפשר לתלמיד להוסיף מבחן לפני שעבר שבוע מהפעם הקודמת
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void TestGap(Test b)
        {
            Range = b.confirmationTestDate.DayOfYear - b.PreviousTestDate.DayOfYear;
            if
                (b.PreviousTestDate != null && Range < 7)
            {
                throw new Exception("The tests are too close together");
            }
        }
          

				

		/// <summary>
		/// לא מאפשר לתלמיד להוסיף מבחן לפני שעבר 20 שיעורים
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void CheckLessons(Trainee d, Test b)
		{
            if (d.NumberOfLessons < 20)
				throw new Exception("You have not done enough lessons");
		}

		/// <summary>
		///  אין אפשרות להוסיף מבחן אם אין בוחן זמין, במקרה כזה הפונקציה תתן תאריך אחר
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void Availability(Test b)
		{
			bool flag = false;
			DayOfWeek today = DateTime.Now.DayOfWeek;
            foreach (Tester item in DAL.getListTesters()) 
			{
                if (b.confirmationTestDate.DayOfWeek >= DayOfWeek.Sunday && b.confirmationTestDate.DayOfWeek <= DayOfWeek.Thursday)
                  
                        flag = true;
				
			}
			 
		}

		/// <summary>
		/// does not allow tester to be added to test if he has surpassed his weekly test limit
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void TesterMax(Tester o)
		{
			if (o.NumTests > Configuration.maxTests)
				throw new Exception("You have done too many tests");
		}

		/// <summary>
		/// does not allow test to be modified if it is missing fields
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void CheckFields(Test b)
		{
			var properties = b.GetType().GetProperties(System.Reflection.BindingFlags.Public);
			foreach (var prop in properties)
			{
				if (!prop.CanRead)
					continue;
				else if (prop.PropertyType.IsValueType)
					continue;
				Object value = prop.GetValue(prop.GetGetMethod().IsStatic ? null : b);
				if (Object.ReferenceEquals(null, value))
					throw new Exception("not all fields have been filled in");
				String str = value as String;
				if (null != str)
					if (str.Equals(""))
						throw new Exception("not all fields have been filled in");
			}
		}

		/// <summary>
		/// does not allow test to be added if tester or trainee already has test at the same time
		/// </summary>
		/// <param name="o"></param>
		/// <param name="d"></param>
		/// <param name="b"></param>
		/// <returns></returns>
		public void TestTime(Tester o, Trainee d, Test b)
		{
			 
				if (b.confirmationTestDate == o.TestTimes1)
					throw new Exception("tester already has test at that time");

                if (b.confirmationTestDate == d.TestTimes2)
					throw new Exception("trainee already has test at that time");
		}

		/// <summary>
		/// does not allow test to be added if trainee has already passed test on that vehicle type
		/// </summary>
		/// <param name="d"></param>
		/// <param name="b"></param>
		/// <returns></returns>
		public void CheckVehicle(Trainee d, Test b)
		{
			if (d.PassedTests == b.TestType)
				throw new Exception("trainee has already passed test on that vehicle type");
		}

		/// <summary>
		/// ensures that the vehicle type that the trainee learned to drive is the same as the testers vehicle
		/// </summary>
		/// <param name="o"></param>
		/// <param name="d"></param>
		/// <returns></returns>
		public bool SetTest(Tester o, Trainee d)
		{
			if (o.CarType == d.CarType)
				return true;
			else return false;
		}

		/// <summary>
		/// returns list of all testers within certain distance of the given address
		/// </summary>
		/// <param name="address"></param>
		/// <returns></returns>
		public List<Tester> TesterArea(string address)
		{
			var list = from item in DAL.getListTesters()
					   where item.Address == address
					   select item;
			List<Tester> newList = new List<Tester>();
			foreach (var s in list)
				newList.Add(s);
			return newList;

		}

		// <summary>
		/// returns list of all testers who are free at the given time 
		/// </summary>
		/// <param name="time"></param>
		/// <returns></returns>
		public List<Tester> TesterTime(DateTime time)
		{
			List<Tester> newList = new List<Tester>();
			foreach (Tester item in DAL.getListTesters())
				if (item.TestTimes1 != time)
					newList.Add(item);
			return newList;
		}

		// <summary>
		/// returns list of tests organized according to certain condition
		/// </summary>
		/// <param name="condition"></param>
		/// <returns></returns>
        public List<Test> Condition_Tests(conditionDelegate Condition)
		{
            var list = from item in DAL.getListTests  ()
					   where Condition(item)
					   select item;
			List<Test> newList = new List<Test>();
			foreach (var s in list)
				newList.Add(s);
			return newList;

		}

		// <summary>
		/// returns number of tests a trainee has done
		/// </summary>
		/// <param name="d></param>
		/// <returns></returns>
		public int NumTraineeTests(Trainee d)
		{
			return d.NumTests;
		}

		// <summary>
		/// checks if trianee has passed any tests
		/// </summary>
		/// <param name="d></param>
		/// <returns></returns>
		public bool PassedTest(Trainee d)
		{
			if (d.PassedTests == false)
				return false;
			return true;
		}

		// <summary>
		/// מחזיר את כל המבחנים
		/// </summary>
		/// <param name="time></param>
		/// <returns></returns>
		public List<Test> TestDate(DateTime time)
		{
            var list = from item in DAL.getListTests ()
					   where item.FinalTestDate.Date == time.Date
					   select item;
			List<Test> newList = new List<Test>();
			foreach (var s in  list)
				newList.Add(s);
			return newList;
		}

		public List<Tester> TesterGrouping()
		{
			List<Tester> TesterGroup = new List<Tester>();
			IEnumerable<IGrouping<string, Tester>> TesterGroup1 = from item in DAL.getListTesters()
                                                                   group item by item.VehicleType;
			foreach (var group in TesterGroup1)
			{
				foreach (var item in group)
				{
					TesterGroup.Add(item);
				}
			}
			return TesterGroup;													
		}
        
		public List<Trainee> TraineeTeacherGrouping()
		{
			List<Trainee> TraineeTeacherGroup = new List<Trainee>();
			IEnumerable<IGrouping<string, Trainee>> TraineeTeacherGroup1 = from item in DAL.getListTrainees()
																	       group item by item. Name;
			foreach (var group in TraineeTeacherGroup1)
			{
				foreach (var item in group)
				{
					TraineeTeacherGroup.Add(item);
				}
			}
			return TraineeTeacherGroup;
		}

		public List<Trainee> TraineeSchoolGrouping()
		{
			List<Trainee> TraineeSchoolGroup = new List<Trainee>();
			IEnumerable<IGrouping<string, Trainee>> TraineeSchoolGroup1 = from item in DAL.getListTrainees()
																		   group item by item.SchoolName;
			foreach (var group in TraineeSchoolGroup1)
			{
				foreach (var item in group)
				{
					TraineeSchoolGroup.Add(item);
				}
			}
			return TraineeSchoolGroup;
		}

		public List<Trainee> TraineeTestGrouping()
		{
			List<Trainee> TraineeTestGroup = new List<Trainee>();
			IEnumerable<IGrouping<int, Trainee>> TraineeTestGroup1 = from item in DAL.getListTrainees()
																     group item by item.NumTests;
			foreach (var group in TraineeTestGroup1)
			{
				foreach (var item in group)
				{
					TraineeTestGroup.Add(item);
				}
			}
			return TraineeTestGroup;
		}

		public void AddTester(Tester t)
		{
            if (t.ID.Length != 9)
                throw new Exception("נא למלא מספר ת.ז");

            if (t.Name == null)
                throw new Exception("נא למלא את שם הבוחן");

            if (t.FamilyName == null)
                throw new Exception("נא למלא את שם המשפחה של הבוחן");

            if (t.Phone < 1111111111 || t.Phone > 1111111111)
                throw new Exception("מספר פלאפון אינו תקין");
            int num = t.DateOfBirth.Year - DateTime.Today.Year;
            AgeTe(num);
			DAL.addTester(t);
		}

		public void deleteTester(string num)
		{ 
			DAL.deleteTester(num);
		}

		public void UpdateTester(Tester O)
		{
            if (O.ID.Length != 9)
                throw new Exception("נא למלא מספר ת.ז");

            if (O.Name == null)
                throw new Exception("נא למלא את שם הבוחן");

            if (O.FamilyName == null)
                throw new Exception("נא למלא את שם המשפחה של הבוחן");

            if (O.Phone < 1111111111 || O.Phone > 1111111111)
                throw new Exception("מספר פלאפון אינו תקין");

            AgeTe(DAL.getListTesters().Find(s => s.ID == O.ID).Birthday.Year);
            DAL.updateTester(O);
		}

		public void AddTrainee(Trainee D)
		{
            if (D.ID.Length != 9)
                throw new Exception("נא למלא מספר ת.ז");

            if (D.Name == null)
                throw new Exception("נא למלא את שם הנבחן");

            if (D.FamilyName == null)
                throw new Exception("נא למלא את שם המשפחה של הנבחן");

            if (D.Phone < 1111111111 || D.Phone > 1111111111)
                throw new Exception("מספר פלאפון אינו תקין");


            int num = D.DateOfBirth.Year -   DateTime.Today.Year;
			DAL.updateTrainee(D);
		}

		public void deleteTrainee(string Name)
		{
            DAL.deleteTrainee(Name);
		}

		public void updateTrainee(Trainee D)
		{
            if (D.ID.Length != 9)
                throw new Exception("נא למלא מספר ת.ז");

            if (D.Name == null)
                throw new Exception("נא למלא את שם הנבחן");

            if (D.FamilyName == null)
                throw new Exception("נא למלא את שם המשפחה של הנבחן");

            if (D.Phone < 1111111111 || D.Phone > 1111111111)
                throw new Exception("מספר פלאפון אינו תקין");


            AgeTr(DAL.getListTrainees().Find(s => s.ID == D.ID).Birthday.Year);
            DAL.updateTrainee(D);
		}

		public void AddTest(Test B)
		{
            Trainee tr = DAL.getListTrainees().Find(s => s.ID == B.NumTrainee);
            Tester te = DAL.getListTesters().Find(s => s.ID  == B.NumTester);
			if (SetTest(te, tr))
			{
				TestGap(B);
				CheckLessons(tr, B);
				Availability(B);
				TesterMax(te);
				TestTime(te, tr, B);
				CheckVehicle(tr, B);
                DAL.addTest(B);
			}		    
		}

		public void deleteTest(string o)
		{
            DAL.deleteTest(o);
		}

		public void UpdateTest(Test B)
		{
            if (B.TestNumber ==null)
                throw new Exception(" נא למלא את מספר המבחן ");

            if (B.TesterAddress  == null)
                throw new Exception("נא להזין את כתובת הבוחן");

            if (B.TraineeAddress == null)
                throw new Exception("נא להזין את כתובת הנבחן");

            if (B.TestCity == null)
                throw new Exception("נא למלא את העיר בה מתבצע המבחן ");

            if (B.ID.Length != 9)
                throw new Exception("נא למלא את ת.ז של הנבחן");

            if (B.PhoneTrainee < 1111111111 || B.PhoneTrainee > 1111111111)
            {
                throw new Exception("נא למלא את מספר הטלפון");
            }

            if (B.Date == null)
                throw new Exception("נא למלא את תאריך המבחן");


            CheckFields(B);
            DAL.updateTest(B);
		}

		public List<Tester> TesterList()
		{
            return DAL.getListTesters();
		}

		public List<Trainee> TraineeList()
		{
            return DAL.getListTrainees();
		}

		public List<Test> TestList()
		{
            return DAL.getListTests();
		}
	}
}
   
