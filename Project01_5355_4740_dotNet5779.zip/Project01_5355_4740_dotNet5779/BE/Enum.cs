﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public enum CarType { Private, twoWheeled, medum, weighty, };
    public enum GearType { automatic, manual };
    public enum Gender { male, female };
}
   
