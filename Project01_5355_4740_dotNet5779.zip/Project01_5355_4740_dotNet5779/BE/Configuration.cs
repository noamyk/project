﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
   public class Configuration
    {
        public static int minL { set; get; }
        public static int ageMaxT { set; get; }
        public static int  ageMinS { set; get; }
        public static int Range { set; get; }
        public static int maxTests { get; set; }
        
             


    }
}
