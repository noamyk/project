﻿using System;
using System.Collections.Generic;
using System.Text;
namespace BE
{
   public class Trainee
    {
        

        public string ID { get; set; } 
        public string FamilyName { get; set; }  
        public string Name { get; set; } 
        public DateTime DateOfBirth { get; set; } 
        public Gender Gender { get; set; }  
        public long Phone { get; set; }  
        public string Address { get; set; }  
        public int GearBox { get; set; }
        public string  SchoolName { get; set; }
        public CarType CarType { get; set; }
        public string TeacherName { get; set; }
        public int NumberOfLessons { get; set; }
     
       public bool PassedTests { get; set; }
       public int NumTests { get; set; }
       public DateTime TestTimes2 { get; set; }
       public DateTime Birthday { get; set; }
   
        
    }
}
