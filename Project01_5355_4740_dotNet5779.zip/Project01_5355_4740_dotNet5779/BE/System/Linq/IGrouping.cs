﻿namespace System.Linq
{
    public interface IGrouping
    {
    }
}