﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public struct Address
    {
        public string street { set; get; }
        public int NumStreet { set; get; }
        public string City { set; get; }
    
    }
}
